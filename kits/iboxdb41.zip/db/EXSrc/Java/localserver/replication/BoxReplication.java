package iboxdb.localserver.replication;

import iboxdb.localserver.*;

import java.util.ArrayList;

//BoxReplication.masterReplicate(masterA, new BoxData(p.OutBox)).commit().Assert();
public final class BoxReplication {

	public static Box masterReplicate(Database self, BoxData... data) {
		return masterReplicate(self, Long.MAX_VALUE, data);
	}

	public static Box masterReplicate(Database self, long dest, BoxData... data) {
		if (data == null || data.length < 1) {
			return null;
		}
		Box box = null;

		for (final BoxData d : data) {
			ArrayList<BEntity> actions = d.getActions();

			if (actions != null && actions.size() > 0) {
				box = box == null ? self.cube(dest) : box;

				for (BEntity e : actions) {
					MasterAction(e, (LocalBox) box);
				}
			}
		}
		return box;

	}

	private static boolean MasterAction(BEntity op, LocalBox box) {
		switch (op.ActionType.Ord) {
		case ActionType.Ord_Begin:
			return true;
		case ActionType.Ord_Insert:
			if (IsKeyOnlyTable(op.TableName)) {
				return box.Insert(op.TableName, op.Key, 0).has();
			} else {
				return box.Insert(op.TableName, op.Value, op.Length).has();
			}
		case ActionType.Ord_Delete:
			return box.Delete(op.TableName, op.Key).has();
		case ActionType.Ord_Update:
			if (box.Update(op.TableName, op.Key, op.Value).has()) {
				return true;
			} else {
				return box.Insert(op.TableName, op.Value, op.Length).has();
			}
		}
		return true;
	}

	private static boolean IsKeyOnlyTable(String tableName) {
		return tableName.charAt(0) == '/';
	}

}
