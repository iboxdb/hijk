package example;

import java.io.File;
import java.math.*;
import java.text.NumberFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import iboxdb.localserver.*;
import iboxdb.localserver.replication.*;
import iboxdb.localserver.replication.BoxData.Actions;

//PC: DB.root("../TEST_DATABASE/");
//--
//Android: initAndroid("com.example.fapp");
//  JDB.isAndroid = true;
//  String packageName = "com.example.fapp";
//  DB.root(android.os.Environment.getDataDirectory().getAbsolutePath() + "/data/" + packageName + "/"); 
//--
//System.out.println(example.JDB.run());
//--
public class JDB {

	public static boolean isAndroid = false;

	public static String run() {
		return run(false);
	}

	public static String run(boolean speedTest) {

		try {

			if (!isAndroid) {
				// different path has different write speed on VM.
				String root = "../TEST_DATABASE/";
				DB.root(root);
				println("Path: " + root);
			}

			GettingStarted();

			IsolatedSpace();

			BeyondSQL();

			MasterSlave();

			MasterMaster();

			if (speedTest) {

				SpeedTest();

				ReplicationSpeed(10);
			}

			helper.deleteDB();
			return println("").toString();
		} catch (Throwable ex) {
			return ex.getMessage();
		}
	}

	public static void GettingStarted() {

		println("");
		println("Getting Started");
		helper.deleteDB();

		AutoBox auto;
		{
			DB db = new DB();
			DatabaseConfig cfg = db.getConfig();
			cfg.ensureTable(Member.class, "Table", "Id");
			auto = db.open();
		}

		// key is strong type
		long key = 1L;
		Member m = new Member(key, "Andy");
		auto.insert("Table", m);

		Member o1 = auto.get(Member.class, "Table", key);
		println(o1.getName());

		o1.setName("Kelly");
		auto.update("Table", o1);
		o1 = null;

		Member o2 = auto.get(Member.class, "Table", key);
		println(o2.getName());

		auto.getDatabase().close();
	}

	public static void IsolatedSpace() {

		println("");
		println("Isolated Space: ");
		helper.deleteDB();

		AutoBox auto;
		{
			DB db = new DB();
			DatabaseConfig cfg = db.getConfig();

			// Table Member
			cfg.ensureTable(Member.class, "Member", "Id");
			// stringColumn(length), default length is 32
			cfg.ensureIndex(Member.class, "Member", "Name(20)");

			// Table Product
			// Composite Key Supported
			cfg.ensureTable(Product.class, "Product", "Type", "UId");
			auto = db.open();
		}

		// Creating Isolated Space, the Box.
		long andyId, kellyId;
		try (Box box = auto.cube()) {
			andyId = box.newId();
			kellyId = box.newId();

			Member m = new Member();
			m.setId(andyId);
			m.setName("Andy");
			m.setRegTime((new GregorianCalendar(2013, 1, 2)).getTime());
			box.d("Member").insert(m);
			m = null;

			Member m2 = new Member();
			m2.setId(kellyId);
			m2.setName("Kelly");
			m2.setRegTime((new GregorianCalendar(2013, 1, 3)).getTime());
			box.d("Member").insert(m2);
			m2 = null;

			Product game = new Product();
			game.Type(8);
			game.UId(UUID.fromString("22222222-0000-0000-0000-000000000000"));
			game.Name("MoonFlight");
			// Dynamic Column
			game.put("GameType", "ACT");
			box.d("Product").insert(game);

			CommitResult cr = box.commit();
			if (cr == CommitResult.OK) {
				println("Transaction Committed");
			}
		}

		// Query Object
		try (Box box = auto.cube()) {
			// C-SQL Style, WHERE: > < >= <= == != , &, |, ().
			// case sensitive:
			// Name -> Name , name -> name
			// getName()->Name , getname()->name
			// Name()->Name, name()->name
			for (Member m : box.select(Member.class, "from Member Id==?",
					kellyId)) {
				println("Member: " + m.getName() + " RegTime: "
						+ m.getRegTime());
			}

			// Key-Value Style, Composite-Key Supported
			Product cs = box.d("Product", 8,
					UUID.fromString("22222222-0000-0000-0000-000000000000"))
					.select(Product.class);
			println("KeyValue Get Product: " + cs.Name() + "  Type: "
					+ cs.get("GameType"));

		}
		// Update Object
		try (Box box = auto.cube()) {
			Member mvip = box.d("Member", kellyId).select(Member.class);
			// Update Amount and Name
			mvip.setName("Kelly J");
			mvip.setAmount(BigDecimal.valueOf(100.0));
			box.d("Member").update(mvip);
			CommitResult cr = box.commit();
			// Assert() == cr.Equals(CommitResult.OK)
			cr.Assert();
		}

		// Query Again
		try (Box box = auto.cube()) {
			for (Member m : box.select(Member.class,
					"from Member where Name==?", "Kelly J")) {
				println("C-SQL Query Member: " + m.getName() + "  Amount: "
						+ m.getAmount());
			}
		}
		auto.getDatabase().close();
	}

	public static void BeyondSQL() {

		println("");
		println("BeyondSQL:");
		helper.deleteDB();

		AutoBox auto;
		{
			DB db = new DB();
			DatabaseConfig cfg = db.getConfig();
			cfg.ensureTable(MemberInc.class, "MemberInc", "Id");
			// Update Increment
			cfg.ensureIncrement(MemberInc.class, "MemberInc", "Version");
			auto = db.open();
		}

		// Update Increment
		print("Version Automatically Increasing: ");

		MemberInc m = new MemberInc();
		m.setId(1L);
		m.setName("Andy");

		auto.insert("MemberInc", m);
		MemberInc mg = auto.get(MemberInc.class, "MemberInc", 1L);
		print(mg.getVersion() + ".  ");

		auto.update("MemberInc", mg);
		mg = auto.get(MemberInc.class, "MemberInc", 1L);
		print(mg.getVersion() + ".  ");

		auto.update("MemberInc", mg);
		mg = auto.get(MemberInc.class, "MemberInc", 1L);
		println(mg.getVersion() + ".  ");

		// Selecting Tracer
		Box firstBox = auto.cube();
		boolean keepTrace = true;
		Member firstMember = firstBox.d("MemberInc", 1L).select(Member.class,
				keepTrace);

		try (Box secondBox = auto.cube()) {
			mg.setName("Kelly");
			secondBox.d("MemberInc").update(mg);
			secondBox.commit();
		}

		// Changes Automatically detected
		CommitResult firstCR = firstBox.commit();
		if (firstCR != CommitResult.OK) {
			print("Changes Automatically Detected: '" + firstMember.getName()
					+ "' has changed, ");
			Member nm = auto
					.get(Member.class, "MemberInc", firstMember.getId());
			println("new name is '" + nm.getName() + "'");
		}

		// Hot bakcup and reopen
		println("Hot Backup Reopen: ");

		// Backup Path
		long bakaddr = new Date().getTime();
		File bakroot = new File(DatabaseConfig.getFileName(1L, null));
		bakroot = new File(bakroot.getParent(), "/BACKUP/");

		// Backup
		auto.getDatabase().copyTo(bakaddr, bakroot.getPath(), 0);

		// Open Backup
		File bakDBFile = new File(DatabaseConfig.getFileName(bakaddr,
				bakroot.getPath()));
		println("BackupPath: " + bakDBFile.getAbsolutePath());

		AutoBox auto_bak = new DB(bakDBFile).open();
		for (Local o : auto_bak.select("from MemberInc")) {
			println(o.toString());
		}

		auto.getDatabase().close();
		auto_bak.getDatabase().close();
		bakDBFile.delete();
	}

	public static void MasterSlave() {

		println("");
		println("MasterSlave Nodes Replication: ");
		helper.deleteDB();

		// MasterNode uses positive address
		long MasterA_DBAddress = 10;
		// SlaveNode uses negative address
		long SlaveA_DBAddress = -10;

		AutoBox auto;
		{
			DB db = new DB(MasterA_DBAddress);
			db.getConfig().ensureTable(Member.class, "Member", "Id");
			db.setBoxRecycler(new MemoryBoxRecycler());
			auto = db.open();
		}

		AutoBox auto_slave = new DB(SlaveA_DBAddress).open();

		try (Box box = auto.cube()) {
			for (int i = 0; i < 3; i++) {
				Member m = new Member();
				m.setId(box.newId());
				m.setName("A" + i);
				box.d("Member").insert(m);
			}
			box.commit();
		}

		// Database Serialization
		MemoryBoxRecycler recycler = (MemoryBoxRecycler) auto.getDatabase()
				.getBoxRecycler();
		for (BoxData rbox : recycler.asBoxData()) {
			rbox.slaveReplicate(auto_slave.getDatabase()).Assert();
		}

		println("Master Address: " + auto.getDatabase().localAddress()
				+ ", Data:");
		for (Member o : auto.select(Member.class, "from Member")) {
			print(o.getName() + ". ");
		}
		println("");

		println("Slave Address: " + auto_slave.getDatabase().localAddress()
				+ ", Data:");
		for (Member o : auto_slave.select(Member.class, "from Member")) {
			print(o.getName() + ". ");
		}
		println("");

		auto.getDatabase().close();
		auto_slave.getDatabase().close();
	}

	public static void MasterMaster() {

		println("");
		println("MasterMaster Nodes Replication: ");

		helper.deleteDB();
		long MasterA_DBAddress = 10;
		long MasterB_DBAddress = 20;

		AutoBox auto_masterA;
		{
			DB db_masterA = new DB(MasterA_DBAddress);
			db_masterA.getConfig().ensureTable(Member.class, "Member", "Id");
			db_masterA.setBoxRecycler(new MemoryBoxRecycler());
			// send to MasterB_DBAddress
			auto_masterA = db_masterA.open(MasterB_DBAddress);
		}

		AutoBox auto_masterB;
		{
			DB db_masterB = new DB(MasterB_DBAddress);
			db_masterB.getConfig().ensureTable(Member.class, "Member", "Id");
			db_masterB.setBoxRecycler(new MemoryBoxRecycler());
			// send to MasterA_DBAddress
			auto_masterB = db_masterB.open(MasterA_DBAddress);
		}
		byte IncTableId = 1;

		try (Box box = auto_masterA.cube()) {
			for (int i = 0; i < 3; i++) {
				Member m = new Member();
				m.setId(box.newId(IncTableId, 1) * 1000 + MasterA_DBAddress);
				m.setName("A" + i);
				box.d("Member").insert(m);
			}
			box.commit();
		}

		try (Box box = auto_masterB.cube()) {
			for (int i = 0; i < 3; i++) {
				Member m = new Member();
				m.setId(box.newId(IncTableId, 1) * 1000 + MasterB_DBAddress);
				m.setName("B" + i);
				box.d("Member").insert(m);
			}
			box.commit();
		}

		// Do Replication
		ArrayList<BoxData> buffer = new ArrayList<BoxData>();
		MemoryBoxRecycler recycler = (MemoryBoxRecycler) auto_masterA
				.getDatabase().getBoxRecycler();
		buffer.addAll(recycler.asBoxData());

		recycler = (MemoryBoxRecycler) auto_masterB.getDatabase()
				.getBoxRecycler();
		buffer.addAll(recycler.asBoxData());

		for (BoxData p : buffer) {
			Actions act = p.getActions();
			if (act.Socket.DestAddress == MasterA_DBAddress) {
				p.masterReplicate(auto_masterA.getDatabase());
			}
			if (act.Socket.DestAddress == MasterB_DBAddress) {
				p.masterReplicate(auto_masterB.getDatabase());
			}
		}

		println("MasterA Address: " + auto_masterA.getDatabase().localAddress()
				+ ", Data:");
		for (Map<String, Object> o : auto_masterA.select("from Member")) {
			print(o.get("Name") + ". ");
		}
		println("");

		println("MasterB Address: " + auto_masterB.getDatabase().localAddress()
				+ ", Data:");
		for (Map<String, Object> o : auto_masterB.select("from Member")) {
			print(o.get("Name") + ". ");
		}

		println("");

		auto_masterA.getDatabase().close();
		auto_masterB.getDatabase().close();

		// another replication config
		// Key = [Id,Address] m.Id = box.NewId(IncTableId, 1); m.Address =
		// box.LocalAddress;
		// box.d("Member").Insert(m);

	}

	public static void SpeedTest() throws InterruptedException {

		println("");
		println("Speed: ");
		helper.deleteDB();

		AutoBox _auto;
		{
			DB db = new DB();
			DatabaseConfig cfg = db.getConfig();
			cfg.ensureTable(Member.class, "TSpeed", "Id");

			// Cache
			// cfg.CacheLength = cfg.mb(512);
			// File
			// cfg.FileIncSize = (int) cfg.mb(4);
			// Read Pool
			// cfg.ReadStreamCount = 8;
			// Read Pool
			// cfg.WriteStreamCount = 2;
			_auto = db.open();
		}
		final AutoBox auto = _auto;

		final int threadCount = isAndroid ? 20 : 20000;
		final int objectCount = 10;
		final int poolCount = isAndroid ? 2 : 8;
		println("Begin Insert " + helper.format(threadCount * objectCount)
				+ " objects");
		long begin = System.currentTimeMillis();
		ExecutorService pool = Executors.newFixedThreadPool(poolCount);
		for (int i = 0; i < threadCount; i++) {
			pool.execute(new Runnable() {
				@Override
				public void run() {
					try (Box box = auto.cube()) {
						for (int o = 0; o < objectCount; o++) {
							Member m = new Member();
							m.setId(box.newId(0, 1));
							m.setName(o + "_" + m.getId());
							m.setAge(1);

							box.d("TSpeed").insert(m);
						}
						box.commit();
					}
				}
			});
		}
		pool.shutdown();
		pool.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);

		double sec = (System.currentTimeMillis() - begin) / 1000.0;
		double avg = (threadCount * objectCount) / sec;
		println("Elapsed " + helper.getDou(sec) + "s, AVG Insert "
				+ helper.format(avg) + " o/sec");

		begin = System.currentTimeMillis();
		pool = Executors.newFixedThreadPool(poolCount);
		for (int fi = 0; fi < threadCount; fi++) {
			final int i = fi;
			pool.execute(new Runnable() {
				@Override
				public void run() {
					try (Box box = auto.cube()) {
						for (int o = 0; o < objectCount; o++) {
							long Id = i * objectCount + o + 1;
							Member mem = box.d("TSpeed", Id).select(
									Member.class);
							if (mem.getId() != Id) {
								throw new RuntimeException();
							}
						}
					}
				}
			});
		}
		pool.shutdown();
		pool.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		sec = (System.currentTimeMillis() - begin) / 1000.0;
		avg = (threadCount * objectCount) / sec;
		println("Elapsed " + helper.getDou(sec) + "s, AVG Lookup "
				+ helper.format(avg) + " o/sec");

		System.gc();
		final AtomicInteger count = new AtomicInteger(0);
		begin = System.currentTimeMillis();
		pool = Executors.newFixedThreadPool(poolCount);
		for (int i = 0; i < threadCount; i++) {
			final int finalI = i;
			pool.execute(new Runnable() {
				@Override
				public void run() {
					try (Box box = auto.cube()) {
						Iterable<Member> tspeed = box.select(Member.class,
								"from TSpeed where Id>=? & Id<=?",
								(long) (finalI * objectCount + 1),
								(long) (finalI * objectCount + objectCount));
						for (Member m : tspeed) {
							// age == 1
							count.addAndGet(m.getAge());
						}
					}
				}
			});
		}
		pool.shutdown();
		pool.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		sec = (System.currentTimeMillis() - begin) / 1000.0;
		avg = (threadCount * objectCount) / sec;

		if (count.get() != (threadCount * objectCount)) {
			throw new RuntimeException("e " + count.get());
		}

		println("Elapsed " + helper.getDou(sec) + "s, AVG Query "
				+ helper.format(avg) + " o/sec");

		auto.getDatabase().close();
	}

	public static void ReplicationSpeed(int time) throws InterruptedException {

		println("");
		helper.deleteDB();

		int MasterA_DBAddress = 10;
		int MasterB_DBAddress = 20;

		int SlaveA_DBAddress = -10;

		AutoBox _auto_masterA;
		{
			DB db_masterA = new DB(MasterA_DBAddress);
			db_masterA.getConfig().ensureTable(Member.class, "TSpeed", "Id");
			db_masterA.setBoxRecycler(new MemoryBoxRecycler());
			_auto_masterA = db_masterA.open(MasterB_DBAddress);
		}
		final AutoBox auto_masterA = _auto_masterA;

		final AutoBox auto_slave = new DB(SlaveA_DBAddress).open();

		AutoBox _auto_masterB;
		{
			DB db_masterB = new DB(MasterB_DBAddress);
			db_masterB.getConfig().ensureTable(Member.class, "TSpeed", "Id");
			_auto_masterB = db_masterB.open();
		}
		final AutoBox auto_masterB = _auto_masterB;

		// Initializing
		ArrayList<BoxData> data = ((MemoryBoxRecycler) auto_masterA
				.getDatabase().getBoxRecycler()).asBoxData();
		BoxData.slaveReplicate(auto_slave.getDatabase(),
				data.toArray(new BoxData[0])).Assert();
		BoxData.masterReplicate(auto_masterB.getDatabase(),
				data.toArray(new BoxData[0])).Assert();

		int threadCount = 200;
		if (isAndroid) {
			threadCount = 2;
			time = time > 2 ? 2 : time;
		}
		final int objectCount = 10;

		double slaveSec = 0;
		double masterSec = 0;

		final int poolCount = isAndroid ? 2 : 8;

		for (int t = 0; t < time; t++) {
			ExecutorService pool = Executors.newFixedThreadPool(poolCount);
			for (int i = 0; i < threadCount; i++) {
				pool.execute(new Runnable() {
					@Override
					public void run() {
						try (Box box = auto_masterA.cube()) {
							for (int o = 0; o < objectCount; o++) {
								Member m = new Member();
								m.setId(box.newId(0, 1));
								m.setName(m.getId() + "_" + o);
								m.setAge(1);
								box.d("TSpeed").insert(m);
							}
							box.commit();
						}
					}
				});
			}
			pool.shutdown();
			pool.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
			data = ((MemoryBoxRecycler) auto_masterA.getDatabase()
					.getBoxRecycler()).asBoxData();

			// Replication
			long begin = System.currentTimeMillis();
			BoxData.slaveReplicate(auto_slave.getDatabase(),
					data.toArray(new BoxData[0])).Assert();
			slaveSec += ((System.currentTimeMillis() - begin) / 1000.0);

			begin = System.currentTimeMillis();
			BoxData.masterReplicate(auto_masterB.getDatabase(),
					data.toArray(new BoxData[0])).Assert();
			masterSec += ((System.currentTimeMillis() - begin) / 1000.0);

		}
		println("Replicate " + (threadCount * time) + " transactions, totals "
				+ helper.format(threadCount * objectCount * time) + " objects");
		double avg = (threadCount * objectCount * time) / slaveSec;
		println("SlaveSpeed " + helper.getDou(slaveSec) + "s, AVG "
				+ helper.format(avg) + " o/sec");

		avg = (threadCount * objectCount * time) / masterSec;
		println("MasterSpeed " + helper.getDou(masterSec) + "s, AVG "
				+ helper.format(avg) + " o/sec");

		final AtomicInteger count = new AtomicInteger(0);

		ExecutorService pool = Executors.newFixedThreadPool(poolCount);
		long begin = System.currentTimeMillis();
		final int fthreadCount = threadCount;
		for (int ft = 0; ft < time; ft++) {
			final int t = ft;
			for (int fi = 0; fi < threadCount; fi++) {
				final int i = fi;
				pool.execute(new Runnable() {
					@Override
					public void run() {
						for (int dbc = 0; dbc < 2; dbc++) {
							try (Box box = dbc == 0 ? auto_slave.cube()
									: auto_masterB.cube()) {
								for (int o = 0; o < objectCount; o++) {
									long Id = i * objectCount + o + 1;
									Id += (t * fthreadCount * objectCount);
									Member mem = box.d("TSpeed", Id).select(
											Member.class);
									if (mem.getId() != Id) {
										throw new RuntimeException();
									}
									count.addAndGet(mem.getAge());
								}
							}
						}
					}
				});
			}
		}
		pool.shutdown();
		pool.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		double sec = (System.currentTimeMillis() - begin) / 1000.0;
		if (count.get() != (threadCount * objectCount * time * 2)) {
			throw new RuntimeException();
		}
		avg = count.get() / sec;
		println("Lookup after replication " + helper.getDou(sec) + "s, AVG "
				+ helper.format(avg) + " o/sec");

		if (count.get() != auto_slave.count("from TSpeed")
				+ auto_masterB.count("from TSpeed")) {
			throw new RuntimeException();
		}

		auto_masterA.getDatabase().close();
		auto_slave.getDatabase().close();
		auto_masterB.getDatabase().close();
	}

	public static abstract class IdClass {

		private long _id;

		public long getId() {
			return _id;
		}

		public void setId(long id) {
			_id = id;
		}
	}

	public static class Member extends IdClass {

		public Member() {
		}

		public Member(long id, String name) {
			super.setId(id);
			_name = name;
		}

		private String _name;
		private Date _regTime;
		private BigDecimal _amount;
		private int _age;

		public int getAge() {
			return _age;
		}

		public void setAge(int value) {
			_age = value;
		}

		public Date getRegTime() {
			return _regTime;
		}

		public void setRegTime(Date value) {
			_regTime = value;
		}

		public String getName() {
			return _name;
		}

		public void setName(String value) {
			_name = value;
		}

		public BigDecimal getAmount() {
			return _amount;
		}

		public void setAmount(BigDecimal value) {
			_amount = value;
		}

	}

	public static class MemberInc extends Member {
		// increment type is long
		private long _version;

		public long getVersion() {
			return _version;
		}

		public void setVersion(long version) {
			_version = version;
		}
	}

	// Dynamic object
	@SuppressWarnings("serial")
	public static class Product extends HashMap<String, Object> {

		public int Type() {
			return (Integer) this.get("Type");
		}

		public void Type(int value) {
			this.put("Type", value);
		}

		public UUID UId() {

			return (UUID) this.get("UId");
		}

		public void UId(UUID value) {
			this.put("UId", value);

		}

		public String Name() {
			return (String) this.get("Name");
		}

		public void Name(String value) {
			this.put("Name", value);
		}
	}

	// Recycle boxes, used in Replication
	public static class MemoryBoxRecycler extends IBoxRecycler {
		public static class Package {

			public Package(Socket socket2, byte[] outBox2) {
				Socket = socket2;
				OutBox = outBox2;
			}

			public Socket Socket;
			public byte[] OutBox;
		}

		public ArrayList<Package> packages = new ArrayList<Package>();

		public MemoryBoxRecycler() {
		}

		public MemoryBoxRecycler(String name, DatabaseConfig config) {
			this();
		}

		@Override
		public void onReceived(Socket socket, BoxData outBox, boolean normal) {

			synchronized (packages) {
				if (socket.DestAddress == Long.MAX_VALUE) {
					// default replication address
					return;
				}
				if (!normal) {
					// database restart from poweroff, sample
					if (packages.size() > 0) {
						Package last = packages.get(packages.size() - 1);
						if (last.Socket.ID.equals(socket.ID)) {
							return;
						}
					}
				}
				// save data
				packages.add(new Package(socket, outBox.toBytes()));
			}
		}

		public ArrayList<BoxData> asBoxData() {
			synchronized (packages) {
				ArrayList<BoxData> list = new ArrayList<BoxData>();
				for (Package p : packages) {
					list.add(new BoxData(p.OutBox));
				}
				packages.clear();
				return list;
			}
		}

		@Override
		public void close() {
			packages = null;
		}
	}

	public static class helper {

		public static void deleteDB() {
			if (!BoxSystem.DBDebug.DeleteDBFiles(1, 10, 20, -10)) {
				System.out.println("delete=false,system locks");
			}
		}

		public static String getDou(double d) {
			long l = (long) (d * 1000);
			return Double.toString(l / 1000.0);
		}

		public static String format(double d) {
			return NumberFormat.getInstance().format((int) d);
		}
	}

	private static StringBuilder strout = new StringBuilder();;

	private static StringBuilder println(String msg) {
		strout.append(msg + "\r\n");
		return strout;
	}

	private static StringBuilder print(String msg) {
		strout.append(msg);
		return strout;
	}
}
